package com.example.medquick_minor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
